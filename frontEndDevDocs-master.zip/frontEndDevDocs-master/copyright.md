#### Copyright
```html
&copy; <?php echo date("Y"); ?>
```
