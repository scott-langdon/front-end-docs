```css
/* MEDIA QUERIES */
/* Custom, iPhone Retina - XS */ 
@media only screen and (min-width : 320px) {

}

/* Extra Small Devices, Phones */ 
@media only screen and (min-width : 480px) {

}

/* Small Devices, Tablets - SM */
@media only screen and (min-width : 768px) {

}

/* Medium Devices, Desktops - MD */
@media only screen and (min-width : 992px) {

}

/* Large Devices, Wide Screens - LG */
@media only screen and (min-width : 1200px) {

}
```
